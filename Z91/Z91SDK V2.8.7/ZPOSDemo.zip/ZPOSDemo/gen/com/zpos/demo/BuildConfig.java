/** Automatically generated file. DO NOT MODIFY */
package com.zpos.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}