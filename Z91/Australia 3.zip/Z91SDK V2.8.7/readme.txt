armeabi.zip -- .so format files.
changelog.txt -- record version update changes.
POSx.x.x.xxxx_x.jar -- SDK jar file.
ZPOSDemo.zip -- demo source code which develop with Eclipse,also can import to android studio.
ZPOSDemo.apk -- demo apk file,you can use adb to install it to test. 
ZPosSDKManual.pdf -- list the common api,and guide you how to use it.